<?php
$db_host = "ecsmysql";
$db_user = "cs332g5";
$db_password = "chaecauw";
$db_name = "cs332g5";

$db_connection = mysqli_connect($db_host, $db_user, $db_password, $db_name);

if ( mysqli_connect_errno() ) {
    die( "Database connection failed:" . mysqli_connect_error() . " ( " . mysqli_connect_errno() . ")" );
}

$db_result_query = 'select * from ' . $_POST['tableName'] . ';';
$db_column_query = 'show columns from ' . $_POST['tableName'] . ';';

$db_result = mysqli_query($db_connection,$db_result_query);

checkResult($db_result);

$db_column_names = mysqli_query($db_connection, $db_column_query);
checkColumn($db_column_names);

outputHTML(formatData($db_result,$db_column_names));

function checkQuery($query) {
    if (!$query) {
        die("Database query failed");
    }
}

function checkResult ($query) {
  if (!$query){
	die("DATABASE FAIL IN RESULT");
}

function checkColumn ($query) {
 if (!$query){
	die("DATABASE FAIL IN COLUMNS");
}

}
}

function formatData($result, $columns) {
    $formatted_data = '<table class="table">';

    $formatted_data .= '<tr>';
    while ($row = mysqli_fetch_assoc($columns)) {
        $formatted_data .= '<th>';
        $formatted_data .= $row['Field'];
        $formatted_data .= '</th>';
    }
    $formatted_data .= '</tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        $formatted_data .= '<tr>';

        foreach ($row as $colName => $colValue) {
                $formatted_data .= '<td>';
                $formatted_data .= $row[$colName];
                $formatted_data .= '</td>';
        }

        $formatted_data .= '</tr>';
    }

    $formatted_data .= '</table>';

    return $formatted_data;
}

function outputHTML($formatted_data) {
    echo '
<!DOCTYPE html>
<html>
<head>
	<title> My database </title>
</head>

<body>
  <label class="label">Select a table</label>
  <form method="post" action="form.php">
    <select name="tableName">
      <option value="PLAYER">Player</option>
      <option value="TEAM">Team</option>
      <option value="MANAGER">Manager</option>
      <option value="STADIUM">Stadium</option>
      <option value="HAS"> Has </option>
      <option value="MANAGE"> Manage </option>
      <option value="HOMEBASE"> Homebase </option>	
 </select>
      <input type="submit" value="Submit">
  </form>

    ' . $formatted_data . '

  </body>
  </html>
  ';
}

$db_connection->close();
